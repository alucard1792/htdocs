<?php 

$promedio = $_POST['prome'];
$grado = $_POST['grad'];
$valorMatriculaSecundaria = 1500000;
$valorMatriculaProfecional = 2000000;
$unidades = 0;
$descuento = 0;
$total = 0;

if ($promedio >= 9.5 && $grado = 'secundaria') {
	$unidades = 55;
	$descuento = $valorMatriculaSecundaria * 25 / 100;

}elseif ($promedio >= 9 && $promedio < 9.5 && $grado = 'secundaria') {
	$unidades = 50;
	$descuento = $valorMatriculaSecundaria * 10 / 100;

}elseif ($promedio > 7 && $promedio < 9 && $grado = 'secundaria') {
	$unidades = 50;
	$descuento = 0;

}elseif ($promedio >= 9.5 && $grado = 'profesional') {
	$unidades = 55;
	$descuento = $valorMatriculaSecundaria * 20 / 100;

}elseif ($promedio <= 9.5 && $grado = 'profesional') {
	$unidades = 55;
	$descuento = 0;

}

header("location:indexPromedio.php?promedio=".$promedio ."&grado=".$grado);

 ?>