<!DOCTYPE html>
<html>
	<head>
		<title></title>
	</head>
	<body>

		<form action="controladorPromedio.php" method="post">
			Promedio<input type="number" name="prome" step="0.1"><br>
			<br>
			Grado <input type="text" name="grad"><br>
			<br>
			<input type="submit" name="promedio" >
		</form> 

		<?php 

		if (isset($_GET['promedio'])) {
			echo "Unidades a cursar: ", $_GET['promedio'];
			echo "Descuento correspondiente: ", $_GET['grado'];

			}

		?>

	</body>
</html>